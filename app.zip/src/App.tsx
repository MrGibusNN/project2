import React, { useState } from 'react';
import { Database as DbIcon, Search, Plus, X, BarChart3, CloudLightning } from 'lucide-react';
import ScraperView from './components/ScraperView';
import AnalyticsView from './components/AnalyticsView';

type Tab = {
  id: string;
  type: 'scraper' | 'analytics';
  title: string;
  dbFileName?: string | null;
};

export default function App() {
  const [tabs, setTabs] = useState<Tab[]>([
    { id: 'scraper-1', type: 'scraper', title: 'Парсер' }
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('scraper-1');

  const handleAddAnalyticsTab = () => {
    const id = `analytics-${Date.now()}`;
    setTabs([...tabs, { id, type: 'analytics', title: 'Аналитика' }]);
    setActiveTabId(id);
  };

  const handleAddScraperTab = () => {
    const id = `scraper-${Date.now()}`;
    setTabs([...tabs, { id, type: 'scraper', title: 'Парсер' }]);
    setActiveTabId(id);
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return; // don't close last tab
    
    const idx = tabs.findIndex(t => t.id === id);
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    
    if (activeTabId === id) {
      if (idx > 0) setActiveTabId(newTabs[idx - 1].id);
      else setActiveTabId(newTabs[0].id);
    }
  };

  return (
    <div className="min-h-screen bg-[#000000] text-[#e4e4e7] font-sans antialiased selection:bg-[#3b82f6]/30 flex flex-col">
      {/* Top Navigation / Tab Bar */}
      <header className="border-b border-[#27272a] bg-[#09090b] sticky top-0 z-50 flex items-center shrink-0">
        <div className="flex-1 flex items-center overflow-x-auto custom-scrollbar pt-2 px-2">
          {tabs.map(tab => (
            <div 
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={`group flex items-center gap-2 px-4 py-2 border-t border-x border-transparent rounded-t-lg cursor-pointer transition-all min-w-[140px] max-w-[200px] ${
                activeTabId === tab.id 
                  ? 'bg-[#18181b] border-[#27272a] text-white relative' 
                  : 'text-[#a1a1aa] hover:bg-[#18181b]/50 hover:text-[#d4d4d8]'
              }`}
            >
              {activeTabId === tab.id && (
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-[#3b82f6] rounded-t-lg"></div>
              )}
              {tab.type === 'scraper' ? <CloudLightning size={14} className="shrink-0" /> : <BarChart3 size={14} className="shrink-0" />}
              <span className="text-sm font-medium truncate flex-1">{tab.title}</span>
              {tabs.length > 1 && (
                <button 
                  onClick={(e) => closeTab(tab.id, e)}
                  className={`p-1 rounded-md transition-colors ${activeTabId === tab.id ? 'hover:bg-[#27272a] text-[#a1a1aa] hover:text-white' : 'opacity-0 group-hover:opacity-100 hover:bg-[#27272a]/50 text-[#71717a] hover:text-white'}`}
                >
                  <X size={12} />
                </button>
              )}
            </div>
          ))}
          
          <div className="flex items-center gap-1 ml-2 mb-1 shrink-0">
             <button 
               onClick={handleAddScraperTab}
               className="p-1.5 rounded-lg text-[#71717a] hover:text-white hover:bg-[#27272a] transition-colors"
               title="Новая вкладка (Парсер)"
             >
               <CloudLightning size={16} />
             </button>
             <button 
               onClick={handleAddAnalyticsTab}
               className="p-1.5 rounded-lg text-[#71717a] hover:text-white hover:bg-[#27272a] transition-colors flex items-center gap-1"
               title="Новая вкладка (Аналитика)"
             >
               <Plus size={16} /> <BarChart3 size={14} />
             </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {tabs.map(tab => (
          <div 
            key={tab.id} 
            className={`absolute inset-0 flex flex-col ${activeTabId === tab.id ? 'opacity-100 z-10' : 'opacity-0 -z-10 pointer-events-none hidden'}`}
          >
            {tab.type === 'scraper' ? (
              <ScraperView />
            ) : (
              <AnalyticsView 
                initialDbFileName={tab.dbFileName} 
                onTitleChange={(title) => {
                  setTabs(prev => prev.map(t => t.id === tab.id ? { ...t, title } : t));
                }}
              />
            )}
          </div>
        ))}
      </main>
    </div>
  );
}
