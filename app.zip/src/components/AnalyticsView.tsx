import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, Database as DbIcon, BarChart3, MessageSquare, Search, FileText } from 'lucide-react';
import { ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell, Legend } from 'recharts';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#64748b', '#06b6d4'];

export default function AnalyticsView({ initialDbFileName, onTitleChange }: { initialDbFileName?: string | null, onTitleChange?: (title: string) => void }) {
  const [dbFile, setDbFile] = useState<File | null>(null);
  const [dbFileName, setDbFileName] = useState<string | null>(initialDbFileName || null);

  
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState<any>(null);
  
  const [searchPostId, setSearchPostId] = useState('');
  const [searchCommentText, setSearchCommentText] = useState('');
  const [postStats, setPostStats] = useState<any>(null);
  const [postLoading, setPostLoading] = useState(false);
  const [postError, setPostError] = useState('');
  const [recentPosts, setRecentPosts] = useState<any[]>([]);

  const getTopicColor = (topicName: string) => {
    if (!stats || !stats.topicsData) return '#3b82f6';
    const index = stats.topicsData.findIndex((t: any) => t.name === topicName);
    if (index === -1) return '#3b82f6';
    return COLORS[index % COLORS.length];
  };


  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialDbFileName) {
      setDbFileName(initialDbFileName);
      fetchStats(initialDbFileName);
      fetchRecentPosts(initialDbFileName);
    }
  }, [initialDbFileName]);

  const handleUpload = async (file: File) => {
    setLoading(true);
    setDbFile(file);
    try {
      const formData = new FormData();
      formData.append('db', file);
      
      const res = await fetch('/api/upload-db', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      
      if (data.fileName) {
        setDbFileName(data.fileName);
        if (onTitleChange && data.originalName) {
          onTitleChange(data.originalName);
        } else if (onTitleChange) {
          onTitleChange(file.name);
        }
        fetchStats(data.fileName);
        fetchRecentPosts(data.fileName);
      }
    } catch(err) {
      console.error(err);
      setLoading(false);
    }
  };

  const fetchStats = async (fileName: string) => {
    try {
      const res = await fetch(`/api/stats?fileName=${fileName}`);
      const data = await res.json();
      if (data.success) {
        setStats(data);
      }
    } catch(err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentPosts = async (fileName: string) => {
    try {
      const res = await fetch(`/api/posts?fileName=${fileName}`);
      const data = await res.json();
      if (data.success) {
        setRecentPosts(data.posts);
      }
    } catch (err) {
      console.error("Failed to fetch posts", err);
    }
  };

  const fetchPostStats = async (id: string, fileName: string) => {
    if (!id || !fileName) return;
    try {
      setPostLoading(true);
      setPostError('');
      setPostStats(null);
      setSearchCommentText('');
      const res = await fetch(`/api/post-stats?fileName=${fileName}&postId=${id}`);
      const data = await res.json();
      
      if (data.success) {
        setPostStats(data);
      } else {
        setPostError(data.error || 'Post not found');
      }
    } catch (err: any) {
      setPostError(err.message);
    } finally {
      setPostLoading(false);
    }
  };

  const handleSearchPost = async (e: React.FormEvent) => {
    e.preventDefault();
    fetchPostStats(searchPostId, dbFileName || '');
  };

  return (
    <div className="flex-1 bg-[#000000] text-[#e4e4e7] font-sans overflow-y-auto custom-scrollbar">
      <div className="max-w-7xl mx-auto px-6 py-8">
        
        {!dbFileName ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="mt-20 border-2 border-dashed border-[#27272a] rounded-xl bg-[#09090b] p-16 flex flex-col items-center justify-center cursor-pointer hover:border-[#3b82f6]/50 hover:bg-[#27272a]/20 transition-all text-center"
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".db,.sqlite,.sqlite3" 
              onChange={(e) => {
                if (e.target.files?.[0]) handleUpload(e.target.files[0]);
              }} 
            />
            
            <div className="w-16 h-16 rounded-2xl bg-[#27272a]/50 flex items-center justify-center mb-6">
              <UploadCloud className="w-8 h-8 text-[#a1a1aa]" />
            </div>
            <h3 className="text-xl font-medium text-white mb-2">Загрузите базу данных</h3>
            <p className="text-[#a1a1aa] text-sm max-w-sm mb-6">
              Выберите файл .db экспортированный из предыдущей программы, чтобы увидеть аналитику и статистику.
            </p>
            {loading && <div className="text-sm text-[#3b82f6] animate-pulse">Загрузка и обработка...</div>}
          </div>
        ) : (
          <div className="space-y-8">
            
            {/* Global Stats View */}
            {stats && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Metric Cards */}
                <div className="col-span-1 space-y-6">
                  <div className="bg-[#09090b] border border-[#27272a] rounded-xl p-6">
                    <div className="flex items-center gap-3 mb-2 text-[#a1a1aa]">
                      <FileText className="w-4 h-4" />
                      <h3 className="text-xs font-semibold uppercase tracking-wider">Всего постов</h3>
                    </div>
                    <div className="text-4xl font-bold text-white">{stats.totalPosts.toLocaleString()}</div>
                  </div>
                  
                  <div className="bg-[#09090b] border border-[#27272a] rounded-xl p-6">
                    <div className="flex items-center gap-3 mb-2 text-[#a1a1aa]">
                      <MessageSquare className="w-4 h-4" />
                      <h3 className="text-xs font-semibold uppercase tracking-wider">Всего комментариев</h3>
                    </div>
                    <div className="text-4xl font-bold text-white">{stats.totalComments.toLocaleString()}</div>
                  </div>
                </div>

                {/* Pie Chart */}
                <div className="col-span-2 bg-[#09090b] border border-[#27272a] rounded-xl p-6">
                   <h3 className="text-sm font-medium mb-6">Распределение тем постов (Нейросеть)</h3>
                   {stats.topicsData && stats.topicsData.length > 0 ? (
                     <div className="h-[300px] w-full">
                       <ResponsiveContainer width="100%" height="100%">
                         <PieChart>
                           <Pie
                             data={stats.topicsData}
                             cx="50%"
                             cy="50%"
                             innerRadius={80}
                             outerRadius={120}
                             paddingAngle={2}
                             dataKey="value"
                             stroke="none"
                           >
                             {stats.topicsData.map((entry: any, index: number) => (
                               <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                             ))}
                           </Pie>
                           <Tooltip 
                              contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', borderRadius: '8px' }}
                              itemStyle={{ color: '#e4e4e7' }}
                           />
                           <Legend layout="vertical" verticalAlign="middle" align="right" wrapperStyle={{ fontSize: '12px' }} />
                         </PieChart>
                       </ResponsiveContainer>
                     </div>
                   ) : (
                     <div className="h-full flex items-center justify-center text-[#a1a1aa] text-sm">Нет данных по темам</div>
                   )}
                </div>

              </div>
            )}

            {/* Post Search View */}
            <div className="bg-[#09090b] border border-[#27272a] rounded-xl p-6">
               <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                 <div>
                   <h3 className="text-sm font-medium">Аналитика конкретного поста</h3>
                   <p className="text-xs text-[#a1a1aa]">Введите ID поста, чтобы посмотреть график активности комментариев</p>
                 </div>
                 <form onSubmit={handleSearchPost} className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]" />
                      <input 
                        type="text" 
                        value={searchPostId}
                        onChange={e => setSearchPostId(e.target.value)}
                        placeholder="ID поста (напр. 311)" 
                        className="w-48 pl-9 pr-3 py-2 bg-[#18181b] border border-[#27272a] rounded-lg text-sm focus:outline-none focus:border-[#3b82f6] text-white transition-colors"
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={postLoading || !searchPostId}
                      className="px-4 py-2 bg-[#3b82f6] hover:bg-[#2563eb] disabled:opacity-50 text-white rounded-lg text-sm font-medium transition-colors"
                    >
                      {postLoading ? 'Поиск...' : 'Найти'}
                    </button>
                 </form>
               </div>

               {postError && (
                 <div className="p-4 bg-red-900/20 border border-red-900/50 rounded-lg text-red-200 text-sm mb-6">
                   {postError}
                 </div>
               )}

               {!postStats && !postLoading && !postError && recentPosts.length > 0 && (
                 <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-6 mb-6">
                    <h4 className="text-sm font-medium mb-4 text-[#e4e4e7]">Последние посты</h4>
                    <div className="flex flex-col gap-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                       {recentPosts.map((p) => (
                         <button 
                           key={p.post_id}
                           onClick={() => {
                              setSearchPostId(p.post_id.toString());
                              fetchPostStats(p.post_id.toString(), dbFileName!);
                           }}
                           className="flex flex-col text-left p-3 rounded bg-[#27272a]/30 hover:bg-[#27272a] border border-transparent hover:border-[#3f3f46] transition-colors"
                         >
                            <div className="flex items-center gap-2 mb-1">
                               <span className="text-xs text-[#a1a1aa]">#{p.post_id}</span>
                               {p.topic && (
                                 <span 
                                   className="text-[10px] font-medium px-1.5 py-0.5 rounded"
                                   style={{ backgroundColor: `${getTopicColor(p.topic)}33`, color: getTopicColor(p.topic) }}
                                 >
                                   {p.topic}
                                 </span>
                               )}
                               <span className="text-xs text-[#71717a] ml-auto">
                                  {new Date(p.date * 1000).toLocaleString()}
                               </span>
                            </div>
                            <span className="text-sm text-[#d4d4d8] line-clamp-2">
                              {p.text || '[Без текста]'}
                            </span>
                         </button>
                       ))}
                    </div>
                 </div>
               )}

               {postStats && (
                 <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <button 
                      onClick={() => {
                        setPostStats(null);
                        setSearchPostId('');
                      }}
                      className="flex items-center gap-2 text-sm text-[#a1a1aa] hover:text-white transition-colors mb-2"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                      Назад к списку постов
                    </button>
                    <div className="p-4 bg-[#18181b] rounded-lg border border-[#27272a]">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs font-mono text-[#71717a]">#{postStats.post.post_id}</span>
                        {postStats.postTopic?.topic && (
                          <span 
                            className="text-[10px] px-2 py-0.5 border rounded-full font-medium uppercase tracking-wider"
                            style={{ 
                              backgroundColor: `${getTopicColor(postStats.postTopic.topic)}1A`, 
                              color: getTopicColor(postStats.postTopic.topic),
                              borderColor: `${getTopicColor(postStats.postTopic.topic)}33`
                            }}
                          >
                            {postStats.postTopic.topic}
                          </span>
                        )}
                        <span className="text-[10px] text-[#71717a] ml-auto">{new Date(postStats.post.date * 1000).toLocaleString()}</span>
                      </div>
                      <p className="text-sm text-[#e4e4e7] line-clamp-3">
                        {postStats.post.text}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-6">
                        <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
                          <span>Активность комментариев</span>
                          <span className="text-xs px-2 py-0.5 bg-[#27272a] text-[#a1a1aa] rounded-full">Всего: {postStats.commentsCount}</span>
                        </h4>
                        {postStats.commentsByDate && postStats.commentsByDate.length > 0 ? (
                          <div className="h-[250px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <BarChart data={postStats.commentsByDate}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                                <XAxis 
                                  dataKey="date" 
                                  tick={{ fill: '#71717a', fontSize: 10 }} 
                                  tickFormatter={(val) => {
                                    const d = new Date(val);
                                    return `${d.getDate()}.${d.getMonth()+1} ${d.getHours()}:00`;
                                  }}
                                  axisLine={false}
                                  tickLine={false}
                                />
                                <YAxis 
                                  tick={{ fill: '#71717a', fontSize: 10 }} 
                                  axisLine={false}
                                  tickLine={false}
                                />
                                <Tooltip 
                                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', borderRadius: '8px' }}
                                  itemStyle={{ color: '#e4e4e7' }}
                                  labelStyle={{ color: '#a1a1aa', fontSize: '12px', marginBottom: '4px' }}
                                />
                                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        ) : (
                          <div className="h-[250px] flex items-center justify-center text-[#a1a1aa] text-sm">
                            Нет данных активности
                          </div>
                        )}
                      </div>
                      
                      <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-6">
                        <h4 className="text-sm font-medium mb-4">Тональность комментариев</h4>
                        {postStats.commentsRelation && postStats.commentsRelation.length > 0 ? (
                          <div className="h-[250px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={postStats.commentsRelation}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={60}
                                  outerRadius={90}
                                  paddingAngle={2}
                                  dataKey="value"
                                  stroke="none"
                                >
                                  {postStats.commentsRelation.map((entry: any, index: number) => {
                                    let color = COLORS[index % COLORS.length];
                                    if (entry.name === 'positive') color = '#10b981';
                                    else if (entry.name === 'negative') color = '#ef4444';
                                    else if (entry.name === 'neutral') color = '#64748b';
                                    return <Cell key={`cell-${index}`} fill={color} />;
                                  })}
                                </Pie>
                                <Tooltip 
                                  contentStyle={{ backgroundColor: '#09090b', borderColor: '#27272a', borderRadius: '8px' }}
                                  itemStyle={{ color: '#e4e4e7' }}
                                />
                                <Legend layout="horizontal" verticalAlign="bottom" align="center" wrapperStyle={{ fontSize: '12px' }} />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                        ) : (
                          <div className="h-[250px] flex items-center justify-center text-[#a1a1aa] text-sm">
                            Нет данных тональности
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="bg-[#18181b] border border-[#27272a] rounded-lg p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                        <h4 className="text-sm font-medium">Поиск по комментариям ({postStats.comments?.length || 0})</h4>
                        <input
                          type="text"
                          placeholder="Поиск..."
                          value={searchCommentText}
                          onChange={(e) => setSearchCommentText(e.target.value)}
                          className="w-full md:w-64 px-4 py-2 bg-[#09090b] border border-[#27272a] rounded-lg focus:outline-none focus:border-[#3b82f6] text-sm text-[#e4e4e7]"
                        />
                      </div>
                      

                      <div className="flex flex-col gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {(() => {
                           const commentsList = postStats.comments || [];
                           const filtered = commentsList.filter((c: any) => 
                             c.text && c.text.toLowerCase().includes(searchCommentText.toLowerCase())
                           );
                           
                           if (filtered.length === 0) {
                             return <div className="text-center text-[#a1a1aa] text-sm py-4">Нет комментариев, соответствующих поиску</div>;
                           }
                           
                           return filtered.map((c: any) => (
                             <div key={c.comment_id} className="p-3 bg-[#27272a]/20 border border-[#27272a] rounded-lg text-sm relative group hover:bg-[#27272a]/40 transition-colors">
                               <div className="flex justify-between items-start mb-2">
                                  <span className="text-[#a1a1aa] text-xs">ID: {c.comment_id} | Пользователь: {c.user_id}</span>
                                  <div className="flex flex-col items-end gap-1">
                                    <span className="text-[#71717a] text-xs">{new Date(c.date * 1000).toLocaleString()}</span>
                                    {c.relation && (
                                      <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                                        c.relation === 'positive' ? 'bg-[#10b981]/20 text-[#10b981]' : 
                                        c.relation === 'negative' ? 'bg-[#ef4444]/20 text-[#ef4444]' : 
                                        'bg-[#64748b]/20 text-[#64748b]'
                                      }`}>
                                        {c.relation === 'positive' ? 'Позитив' : c.relation === 'negative' ? 'Негатив' : 'Нейтрально'}
                                        {(() => {
                                          const conf = c.confidence_score !== undefined ? c.confidence_score : c.score;
                                          return conf !== undefined && conf !== null ? ` (${Math.round(conf * 100)}%)` : '';
                                        })()}
                                      </span>
                                    )}
                                  </div>
                               </div>
                               <p className="text-[#d4d4d8] mb-1 whitespace-pre-wrap">{c.text}</p>
                             </div>
                           ));
                        })()}
                      </div>
                    </div>

                 </div>
               )}

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
