import React, { useState, useEffect } from 'react';
import { BarChart3, Database as DatabaseIcon, FileText, MessageSquare, Download, Search, LayoutGrid, Key, Hash, Phone, Calendar, Layers, Eye, EyeOff, CheckCircle, Zap } from 'lucide-react';
import { cn } from '../lib/utils';

type Stats = { totalPosts: number; totalComments: number };

export default function ScraperView() {
  const [stats, setStats] = useState<Stats>({ totalPosts: 0, totalComments: 0 });
  const [channelName, setChannelName] = useState('');
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [isScraping, setIsScraping] = useState(false);
  
  // MTProto Auth State
  const [mtprotoStatus, setMtprotoStatus] = useState<'disconnected' | 'connected'>('disconnected');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authStep, setAuthStep] = useState<'setup' | 'waiting' | 'code' | 'password'>('setup');
  
  // MTProto Credentials
  const [apiId, setApiId] = useState('');
  const [apiHash, setApiHash] = useState('');
  const [phone, setPhone] = useState('');
  const [showApiId, setShowApiId] = useState(false);
  const [showApiHash, setShowApiHash] = useState(false);
  const [authCode, setAuthCode] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [showAuthPassword, setShowAuthPassword] = useState(false);
  
  const [activeMedia, setActiveMedia] = useState<string[] | null>(null);

  // Limit state
  const [limitMode, setLimitMode] = useState<'count' | 'date'>('count');
  const [postCount, setPostCount] = useState<number | string>(100);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  
  const [currentDbFileName, setCurrentDbFileName] = useState<string | null>(null);

  useEffect(() => {
    // Check initial MTProto status
    fetch('/api/auth/status')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'authenticated') {
          setMtprotoStatus('connected');
        }
      }).catch(() => {});
  }, []);

  const executeScrape = async () => {
    if (!channelName) return;
    setIsScraping(true);
    setStats({ totalPosts: 0, totalComments: 0 }); // reset before new scrape
    try {
      const res = await fetch('/api/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          channel: channelName, 
          useMTProto: mtprotoStatus === 'connected', 
          apiId, 
          apiHash, 
          phone,
          limitMode,
          countLimit: postCount,
          dateFrom,
          dateTo
        }),
      });
      const data = await res.json();
      setPreviewData(data.postsPreview);
      
      if (data.dbFileName) {
        setCurrentDbFileName(data.dbFileName);
        const statsRes = await fetch(`/api/stats?fileName=${data.dbFileName}`);
        const statsData = await statsRes.json();
        setStats(statsData);
      }
    } catch (error) {
      console.error('Error fetching preview:', error);
    } finally {
      setIsScraping(false);
    }
  };

  const handleStartAuthFlow = async () => {
    if (!apiId || !apiHash || !phone) return;
    setAuthStep('waiting');
    try {
      await fetch('/api/auth/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiId, apiHash, phone })
      });
      pollAuthStatus();
    } catch (err) {
      console.error(err);
      setAuthStep('setup');
    }
  };

  const pollAuthStatus = async () => {
    try {
      const res = await fetch('/api/auth/status');
      const data = await res.json();
      
      if (data.status === 'waiting_code') {
        setAuthStep('code');
      } else if (data.status === 'waiting_password') {
        setAuthStep('password');
      } else if (data.status === 'authenticated') {
        setMtprotoStatus('connected');
        setShowAuthModal(false);
      } else if (data.status === 'idle') {
        // Failed or reset
        setAuthStep('setup');
      } else {
        // still waiting or processing, poll again
        setTimeout(pollAuthStatus, 1000);
      }
    } catch (err) {
      setTimeout(pollAuthStatus, 1000);
    }
  };

  const handleAuthSubmitCodeOrPassword = async () => {
    if (authStep === 'code') {
      setAuthStep('waiting');
      await fetch('/api/auth/provideCode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: authCode })
      });
      pollAuthStatus();
    } else if (authStep === 'password') {
      setAuthStep('waiting');
      await fetch('/api/auth/providePassword', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: authPassword })
      });
      pollAuthStatus();
    }
  };

  const handleDownload = () => {
    if (currentDbFileName) {
      window.location.href = `/api/download-db?fileName=${currentDbFileName}&channel=${channelName ? encodeURIComponent(channelName) : ''}&posts=${stats.totalPosts}&comments=${stats.totalComments}`;
    } else {
      window.location.href = `/api/download-db?channel=${channelName ? channelName.replace(/^@?/, '').replace(/^(?:https?:\/\/)?(?:t\.me\/)?/, '').split('/')[0] : 'database'}`;
    }
  };

  return (
    <div className="flex-1 text-[#e4e4e7] font-sans flex flex-col overflow-hidden">
      {/* Top Header Controls (Inside tab) */}
      <div className="flex items-center justify-between p-4 bg-[#09090b] border-b border-[#27272a] shrink-0">
        <div className="flex items-center gap-3">
          <h2 className="text-sm font-medium">Парсинг данных</h2>
        </div>
        <div className="flex items-center gap-4">
          <div className={cn("flex items-center gap-2 px-3 py-1 rounded-full border", mtprotoStatus === 'connected' ? "bg-emerald-900/30 border-emerald-800" : "bg-slate-800 border-slate-700")}>
            <div className={cn("w-2 h-2 rounded-full", mtprotoStatus === 'connected' ? "bg-emerald-500 animate-pulse" : "bg-slate-500")}></div>
            <span className={cn("text-xs font-mono uppercase tracking-widest", mtprotoStatus === 'connected' ? "text-emerald-400" : "text-slate-400")}>MTProto {mtprotoStatus === 'connected' ? 'Активен' : 'Неактивен'}</span>
          </div>
          <button 
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-1.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded-lg text-xs font-bold transition-all"
          >
            <DatabaseIcon size={14} />
            <span>Экспорт .db</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: Configuration */}
        <aside className="w-72 border-r border-[#27272a] bg-[#18181b] p-6 flex flex-col gap-6 shrink-0 overflow-y-auto custom-scrollbar">
          <section>
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-[0.2em] mb-3 block">Цель архивации</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
              <input 
                type="text" 
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                placeholder="имя_канала"
                className="w-full bg-[#09090b] border border-[#27272a] rounded-lg py-2 pl-8 pr-4 text-sm focus:outline-none focus:border-[#3b82f6] transition-all placeholder-[#71717a] text-white" 
              />
            </div>
          </section>

          <section className="space-y-4">
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-[0.2em] block">Режим выгрузки</label>
            <div className="flex bg-[#09090b] border border-[#27272a] rounded-lg p-1">
              <button
                onClick={() => setLimitMode('count')}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-1.5 text-xs font-semibold rounded-md transition-all",
                  limitMode === 'count' ? "bg-[#3b82f6] text-white shadow" : "text-[#a1a1aa] hover:text-white"
                )}
              >
                <Layers size={14} />
                <span>По количеству</span>
              </button>
              <button
                onClick={() => setLimitMode('date')}
                className={cn(
                  "flex-1 flex items-center justify-center gap-2 py-1.5 text-xs font-semibold rounded-md transition-all",
                  limitMode === 'date' ? "bg-[#3b82f6] text-white shadow" : "text-[#a1a1aa] hover:text-white"
                )}
              >
                <Calendar size={14} />
                <span>По дате</span>
              </button>
            </div>

            {limitMode === 'count' ? (
              <div className="relative">
                <input 
                  type="number" 
                  value={postCount}
                  onChange={(e) => setPostCount(e.target.value)}
                  placeholder="Количество постов"
                  className="w-full bg-[#09090b] border border-[#27272a] rounded-lg py-2 px-4 text-sm focus:outline-none focus:border-[#3b82f6] transition-all placeholder-[#71717a] text-white" 
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-[#71717a] font-medium">шт.</span>
              </div>
            ) : (
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input 
                    type="date" 
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg py-2 px-3 text-xs focus:outline-none focus:border-[#3b82f6] transition-all text-white [color-scheme:dark]" 
                  />
                  <span className="absolute -top-2 left-3 bg-[#18181b] px-1 text-[8px] uppercase tracking-wider text-[#a1a1aa] font-bold">От</span>
                </div>
                <div className="relative flex-1">
                  <input 
                    type="date" 
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                    className="w-full bg-[#09090b] border border-[#27272a] rounded-lg py-2 px-3 text-xs focus:outline-none focus:border-[#3b82f6] transition-all text-white [color-scheme:dark]" 
                  />
                  <span className="absolute -top-2 left-3 bg-[#18181b] px-1 text-[8px] uppercase tracking-wider text-[#a1a1aa] font-bold">До</span>
                </div>
              </div>
            )}
          </section>

          <section className="space-y-4">
            <label className="text-[10px] uppercase font-bold text-slate-500 tracking-[0.2em] block">Параметры парсинга</label>
            
            <button 
              onClick={() => setShowAuthModal(true)}
              className={cn(
                "w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-semibold transition-all border",
                mtprotoStatus === 'connected' 
                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20" 
                  : "bg-[#27272a] text-[#d4d4d8] border-[#3f3f46] hover:bg-[#3f3f46]"
              )}
            >
              <span className="flex items-center gap-2">
                <Zap size={16} className={mtprotoStatus === 'connected' ? 'text-emerald-400' : 'text-[#a1a1aa]'} />
                {mtprotoStatus === 'connected' ? 'MTProto Подключен' : 'Подключить MTProto'}
              </span>
              {mtprotoStatus === 'connected' && <CheckCircle size={16} />}
            </button>

            <div className="flex items-center justify-between group opacity-50 cursor-not-allowed">
              <span className="text-xs text-[#a1a1aa]">Сохранять медиа</span>
              <div className="w-8 h-4 bg-[#3b82f6] rounded-full relative">
                <div className="absolute right-1 top-1 w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
          </section>

          <section className="mt-auto pt-4 border-t border-[#27272a]">
            <button 
              onClick={executeScrape}
              disabled={isScraping || !channelName}
              className="w-full px-6 py-2.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded-lg text-sm font-bold shadow-lg shadow-blue-900/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isScraping ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Парсинг...</span>
                </>
              ) : (
                <>
                  <Search size={16} />
                  <span>Начать парсинг</span>
                </>
              )}
            </button>
          </section>
        </aside>

        {/* Main Content: Data View */}
        <div className="flex-1 flex flex-col p-6 gap-6 overflow-y-auto custom-scrollbar bg-[#09090b]">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 shrink-0">
            {/* Stats Column */}
            <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-6 flex flex-col justify-center shadow-sm">
              <div className="flex items-center gap-2 text-[#a1a1aa] mb-4 text-[10px] uppercase font-bold tracking-widest">
                <FileText size={14} />
                <span>Обработано постов</span>
              </div>
              <div className="text-4xl font-mono font-bold text-white tracking-tight">{stats?.totalPosts || 0}</div>
            </div>
            
            <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-6 flex flex-col justify-center shadow-sm">
              <div className="flex items-center gap-2 text-[#a1a1aa] mb-4 text-[10px] uppercase font-bold tracking-widest">
                <MessageSquare size={14} />
                <span>Обработано комментариев</span>
              </div>
              <div className="text-4xl font-mono font-bold text-white tracking-tight">{stats?.totalComments || 0}</div>
            </div>
          </div>

          {/* Preview Grid/Table */}
          {previewData.length > 0 && (
            <div className="flex-1 bg-[#18181b] rounded-2xl border border-[#27272a] flex flex-col min-h-[300px] shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid grid-cols-[80px_1fr_120px] gap-4 p-4 border-b border-[#27272a] text-[10px] uppercase font-bold text-[#71717a] tracking-wider bg-[#09090b]">
                <span>ID Поста</span>
                <span>Фрагмент текста</span>
                <span className="text-right">Медиафайлы</span>
              </div>

              <div className="flex-1 overflow-y-auto custom-scrollbar">
                {previewData.map((post, i) => (
                  <div key={i} className="grid grid-cols-[80px_1fr_120px] gap-4 p-4 border-b border-[#27272a]/50 hover:bg-[#27272a]/30 transition-colors items-center">
                    <span className="font-mono text-xs text-[#3b82f6]">#{post.id}</span>
                    <span className="text-sm text-[#d4d4d8] truncate pr-8">{post.text}</span>
                    <div className="flex items-center justify-end gap-1.5">
                      {post.hasImages ? (
                        <button 
                          onClick={() => setActiveMedia(post.mediaUrls || [])}
                          className="px-3 py-1 bg-[#27272a] hover:bg-[#3f3f46] rounded border border-[#3f3f46] flex items-center gap-2 shrink-0 transition-colors"
                        >
                          <svg className="w-3.5 h-3.5 text-[#a1a1aa]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                          <span className="text-[10px] font-bold text-[#e4e4e7]">Показать ({post.mediaCount})</span>
                        </button>
                      ) : (
                        <span className="text-[#52525b] text-[10px] uppercase font-semibold">Нет медиа</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Bottom Stats Bar */}
              <div className="bg-[#09090b] border-t border-[#27272a] p-4 flex items-center justify-between shrink-0">
                <div className="flex gap-8">
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-bold text-[#71717a] tracking-widest">Обработано</span>
                    <span className="text-sm font-mono text-white font-bold">{previewData.length} <span className="text-xs font-normal text-[#a1a1aa]">шт.</span></span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-bold text-[#71717a] tracking-widest">Найдено медиа</span>
                    <span className="text-sm font-mono text-white font-bold">{previewData.filter(p => p.hasImages).reduce((acc, curr) => acc + (curr.mediaCount || 0), 0)} <span className="text-xs font-normal text-[#a1a1aa]">файлов</span></span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] uppercase font-bold text-[#71717a] tracking-widest">Канал</span>
                    <span className="text-sm font-mono text-white font-bold">@{channelName}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Active Media Modal Overlay */}
      {activeMedia && (
        <div className="fixed inset-0 bg-[#000000]/90 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200" onClick={() => setActiveMedia(null)}>
          <div className="bg-[#09090b] border border-[#27272a] rounded-2xl w-full max-w-4xl shadow-2xl p-6 relative flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4 shrink-0">
              <h3 className="text-lg font-bold text-white">Прикрепленные медиафайлы</h3>
              <button onClick={() => setActiveMedia(null)} className="text-[#a1a1aa] hover:text-white transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 overflow-y-auto pr-2 custom-scrollbar p-2">
              {activeMedia.map((url, idx) => {
                const isVideo = url.match(/\.(mp4|webm)$/i) || url.includes('/api/proxy?url=') || url.includes('type=video');
                return (
                  <div key={idx} className="bg-[#18181b] rounded-xl overflow-hidden border border-[#27272a] flex items-center justify-center relative min-h-[200px]">
                    {url === 'media' ? (
                      <div className="flex flex-col items-center gap-2 p-6 text-center">
                        <span className="text-3xl">📎</span>
                        <span className="text-sm text-[#a1a1aa]">Скрытый медиафайл<br/>(нужен MTProto)</span>
                      </div>
                    ) : isVideo ? (
                      <video 
                        src={url} 
                        controls 
                        className="w-full h-full object-contain max-h-[60vh]"
                        preload="metadata"
                      />
                    ) : (
                      <img 
                        src={url} 
                        alt="Telegram media" 
                        className="w-full h-full object-contain max-h-[60vh]" 
                        loading="lazy"
                      />
                    )}
                    {url !== 'media' && (
                      <a 
                        href={url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="absolute top-2 right-2 p-2 bg-[#09090b]/80 hover:bg-[#18181b] rounded-lg text-white opacity-0 hover:opacity-100 transition-opacity"
                        title="Открыть оригинал"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                      </a>
                    )}
                  </div>
                );
              })}
            </div>
            
            <div className="mt-4 pt-4 border-t border-[#27272a] flex justify-between items-center shrink-0">
              <span className="text-xs font-bold text-[#71717a] uppercase tracking-wider">Всего файлов: {activeMedia.length}</span>
              <button onClick={() => setActiveMedia(null)} className="px-4 py-2 bg-[#27272a] hover:bg-[#3f3f46] text-white text-sm font-semibold rounded-lg transition-colors">
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auth Modal Overlay */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-[#000000]/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#09090b] border border-[#27272a] rounded-2xl w-full max-w-sm shadow-2xl p-6 shadow-blue-900/10">
            <h2 className="text-lg font-bold text-white mb-2">Авторизация MTProto</h2>
            <p className="text-xs text-[#a1a1aa] mb-6">
              {authStep === 'setup' && 'Введите данные API и номер телефона.'}
              {authStep === 'waiting' && 'Ожидание ответа от серверов Telegram...'}
              {authStep === 'code' && 'Введите код подтверждения, отправленный в Telegram'}
              {authStep === 'password' && 'Включена двухэтапная аутентификация. Введите облачный пароль.'}
            </p>

            <div className="space-y-4">
              {authStep === 'setup' && (
                <>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]"><Hash size={14} /></span>
                    <input 
                      type={showApiId ? "text" : "password"} 
                      value={apiId}
                      onChange={(e) => setApiId(e.target.value)}
                      placeholder="API ID"
                      className="w-full bg-[#18181b] border border-[#27272a] rounded-md py-2.5 pl-9 pr-10 text-sm focus:outline-none focus:border-[#3b82f6] transition-all text-white" 
                    />
                    <button onClick={() => setShowApiId(!showApiId)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#71717a] hover:text-[#d4d4d8]">
                      {showApiId ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]"><Key size={14} /></span>
                    <input 
                      type={showApiHash ? "text" : "password"} 
                      value={apiHash}
                      onChange={(e) => setApiHash(e.target.value)}
                      placeholder="API Hash"
                      className="w-full bg-[#18181b] border border-[#27272a] rounded-md py-2.5 pl-9 pr-10 text-sm focus:outline-none focus:border-[#3b82f6] transition-all text-white" 
                    />
                    <button onClick={() => setShowApiHash(!showApiHash)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#71717a] hover:text-[#d4d4d8]">
                      {showApiHash ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]"><Phone size={14} /></span>
                    <input 
                      type="tel" 
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="Телефон (+123...)"
                      className="w-full bg-[#18181b] border border-[#27272a] rounded-md py-2.5 pl-9 pr-3 text-sm focus:outline-none focus:border-[#3b82f6] transition-all text-white" 
                    />
                  </div>
                </>
              )}

              {authStep === 'code' && (
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]"><Hash size={16} /></span>
                  <input 
                    type="text"
                    autoFocus
                    value={authCode}
                    onChange={(e) => setAuthCode(e.target.value)}
                    placeholder="Код подтверждения"
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:border-[#3b82f6] transition-all text-white" 
                  />
                </div>
              )}
              
              {authStep === 'password' && (
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#71717a]"><Key size={16} /></span>
                  <input 
                    type={showAuthPassword ? "text" : "password"}
                    autoFocus
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    placeholder="Облачный пароль"
                    className="w-full bg-[#18181b] border border-[#27272a] rounded-lg py-2.5 pl-10 pr-10 text-sm focus:outline-none focus:border-[#3b82f6] transition-all text-white" 
                  />
                  <button onClick={() => setShowAuthPassword(!showAuthPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#71717a] hover:text-[#d4d4d8]">
                    {showAuthPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button 
                  onClick={() => {
                    setShowAuthModal(false);
                    setAuthStep('setup');
                  }}
                  className="flex-1 py-2.5 bg-[#27272a] hover:bg-[#3f3f46] text-[#d4d4d8] rounded-lg text-sm font-semibold transition-all"
                >
                  {authStep === 'waiting' ? 'Закрыть' : 'Отмена'}
                </button>
                {authStep === 'setup' && (
                  <button 
                    onClick={handleStartAuthFlow}
                    disabled={!apiId || !apiHash || !phone}
                    className="flex-1 py-2.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded-lg text-sm font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <span>Отправить код</span>
                  </button>
                )}
                {(authStep === 'code' || authStep === 'password') && (
                  <button 
                    onClick={handleAuthSubmitCodeOrPassword}
                    disabled={authStep === 'code' ? !authCode : !authPassword}
                    className="flex-1 py-2.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded-lg text-sm font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    <CheckCircle size={16} />
                    <span>Продолжить</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
