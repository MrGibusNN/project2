# Telegram Data Extractor & AI Pipeline

Это приложение позволяет выгружать данные из Telegram каналов (посты, комментарии, ссылки на медиафайлы) в локальную базу данных SQLite или CSV-формат. Затем вы можете использовать скрипты для скачивания или анализа собранных данных локально, без ограничений облачных сервисов.

## 1. Запуск приложения локально (Node.js)

Для запуска интерфейса вам понадобится установленный `Node.js` (рекомендуется версия 18+).

### Установка:

1. Скачайте проект к себе на компьютер.
2. Откройте терминал в папке с проектом (где находится `package.json`).
3. Установите зависимости:
   ```bash
   npm install
   ```

### Конфигурация:

1. Создайте в корне проекта файл `.env` (если его нет).
2. Запустите приложение в режиме разработки:
   ```bash
   npm run dev
   ```
3. Откройте в браузере `http://localhost:3000`

### Сбор данных и авторизация:

Для выгрузки большого количества постов и комментариев (а также приватных данных) вам потребуется авторизация MTProto (в интерфейсе кнопка "Enable MTProto").  
Получите **API_ID** и **API_HASH** на портале [my.telegram.org](https://my.telegram.org) (раздел API development tools).  
Введите их и номер телефона для авторизации. После сбора данных, нажмите кнопку `SQLite DB (.db)` чтобы скачать базу данных `telegram_*.db`.

---

## 2. Локальный анализ медиафайлов через Python

С помощью Python вы можете подключиться к выгруженной SQLite базе данных (`telegram_*.db`), скачать медиафайлы и проанализировать их при помощи любых локальных ИИ (например, Ollama, LLaVa) или скриптов.

### Настройка Python

Вам понадобится Python 3.9+. Установите необходимые библиотеки (замените `google-genai` на `ollama` или другие, если будете использовать локальную модель):

```bash
pip install sqlite3 requests pillow
```

### Пример скрипта (analysis.py)

Ниже приведен базовый скрипт, читающий список ссылок на медиа из БД, скачивающий их и подготавливающий к вашему пайплайну анализа:

```python
import sqlite3
import json
import os
import requests

# 1. Укажите путь к вашей скачанной базе данных
DB_PATH = 'telegram_cyberyozh.db' 
MEDIA_DIR = './downloaded_media'

if not os.path.exists(MEDIA_DIR):
    os.makedirs(MEDIA_DIR)

def download_file(url, out_path):
    try:
        r = requests.get(url, stream=True)
        if r.status_code == 200:
            with open(out_path, 'wb') as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
            return True
    except Exception as e:
        print(f"Ошибка скачивания {url}: {e}")
    return False

def analyze_image_with_ai(image_path, text_context):
    # ==========================================
    # ВСТАВЬТЕ СЮДА ВАШ ЛОКАЛЬНЫЙ ИИ-АНАЛИЗ
    # Например, вызов Ollama CLI, LLaVA, OpenAI 
    # или скрипты компьютерного зрения.
    # ==========================================
    return f"Локальный анализ картинки {image_path} проведен успешно."

def main():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Рекомендуется создать колонку под результаты если ее нет
    try:
        cursor.execute("ALTER TABLE telegram_posts ADD COLUMN scripts_analysis TEXT")
    except sqlite3.OperationalError:
        pass # Колонка уже существует

    cursor.execute("SELECT id, post_id, text, media_urls FROM telegram_posts WHERE media_urls IS NOT NULL")
    posts = cursor.fetchall()

    for row in posts:
        db_id, post_id, text_content, media_json = row
        try:
            media_list = json.loads(media_json)
        except:
            continue
            
        analysis_results = []
        
        for idx, media_url in enumerate(media_list):
            # Простая генерация имени файла
            ext = media_url.split('.')[-1]
            if len(ext) > 5: ext = 'jpg' # фоллбэк
            filename = f"post_{post_id}_media_{idx}.{ext}"
            filepath = os.path.join(MEDIA_DIR, filename)
            
            print(f"Скачивание {media_url}...")
            if download_file(media_url, filepath):
                # Запуск локальной модели для анализа
                result = analyze_image_with_ai(filepath, text_content)
                analysis_results.append(result)
        
        if analysis_results:
            final_report = " | ".join(analysis_results)
            cursor.execute("UPDATE telegram_posts SET scripts_analysis = ? WHERE id = ?", (final_report, db_id))
            conn.commit()
            print(f"Пост {post_id} проанализирован и обновлен в БД.")

    conn.close()
    print("Локальный анализ завершен.")

if __name__ == '__main__':
    main()
```

Запустите скрипт командой:
```bash
python analysis.py
```

После завершения вы можете открыть `.db` файл в DBeaver и увидеть новую колонку `scripts_analysis` с вашими результатами. Вы можете неограниченно использовать локальные Video / Image Vision модели бесплатно!
