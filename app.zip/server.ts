import express from "express";
import path from "path";
import multer from "multer";
import fs from "fs";
import os from "os";
import Database from "better-sqlite3";
import { createServer as createViteServer } from "vite";
import { Api, TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions";

const upload = multer({ dest: os.tmpdir() });

let client: TelegramClient | null = null;
let sessionString = "";
let currentPhone = "";

// Global database for scraper
const scraperDb = new Database("database.db");

// Init tables
scraperDb.prepare(`
  CREATE TABLE IF NOT EXISTS telegram_posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT,
    post_id INTEGER,
    text TEXT,
    date INTEGER,
    views REAL,
    media_urls TEXT
  )
`).run();

scraperDb.prepare(`
  CREATE TABLE IF NOT EXISTS telegram_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT,
    post_id INTEGER,
    comment_id INTEGER,
    text TEXT,
    date INTEGER
  )
`).run();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // --- ANALYTICS ROUTES ---
  app.post("/api/upload-db", upload.single("db"), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      res.json({ success: true, fileName: req.file.filename, originalName: req.file.originalname });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/stats", (req, res) => {
    try {
      const { fileName } = req.query;
      
      let db = scraperDb;
      if (fileName && typeof fileName === "string") {
        const dbPath = path.join(os.tmpdir(), fileName);
        if (fs.existsSync(dbPath)) {
          db = new Database(dbPath, { readonly: true });
        }
      }
      
      let totalPosts = 0;
      let totalComments = 0;
      let topicsData: { name: string, value: number }[] = [];

      try {
        const postsRes = db.prepare("SELECT COUNT(*) as c FROM telegram_posts").get() as any;
        totalPosts = postsRes?.c || 0;
      } catch (e) { /* table might not exist */ }

      try {
        const commentsRes = db.prepare("SELECT COUNT(*) as c FROM telegram_comments").get() as any;
        totalComments = commentsRes?.c || 0;
      } catch (e) { /* table might not exist */ }

      try {
        const topicsRes = db.prepare("SELECT topic, COUNT(*) as c FROM PostTopics GROUP BY topic ORDER BY c DESC").all() as any[];
        topicsData = topicsRes.map(t => ({ name: t.topic, value: t.c }));
      } catch (e) { /* table might not exist */ }

      if (fileName && db !== scraperDb) {
        db.close();
      }
      
      res.json({ success: true, totalPosts, totalComments, topicsData });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/post-stats", (req, res) => {
    try {
      const { fileName, postId } = req.query;
      if (!postId) {
        return res.status(400).json({ error: "postId is required" });
      }
      
      let db = scraperDb;
      if (fileName && typeof fileName === "string") {
        const dbPath = path.join(os.tmpdir(), fileName);
        if (fs.existsSync(dbPath)) {
          db = new Database(dbPath, { readonly: true });
        }
      }

      let post = null;
      let postTopic = null;
      let comments = [];
      let commentsByDate: { date: string, count: number }[] = [];
      let commentsRelation: { name: string, value: number }[] = [];

      try {
        post = db.prepare("SELECT * FROM telegram_posts WHERE post_id = ?").get(postId);
      } catch (e) {}

      if (!post) {
        if (fileName && db !== scraperDb) db.close();
        return res.status(404).json({ error: "Post not found in database" });
      }

      try {
        postTopic = db.prepare("SELECT * FROM PostTopics WHERE post_id = ?").get(postId);
      } catch (e) {}

      let debugError = "";
      let crTableName = 'CommentRelation';
      try {
        const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all() as any[];
        for (const t of tables) {
          const schema = db.prepare(`PRAGMA table_info("${t.name}")`).all() as any[];
          if (schema.some(c => c.name.toLowerCase() === 'relation') && t.name !== 'telegram_comments' && t.name !== 'telegram_posts') {
            crTableName = t.name;
            break;
          }
        }

        const crSchema = db.prepare(`PRAGMA table_info("${crTableName}")`).all() as any[];
        const crColumns = crSchema.map(c => c.name.toLowerCase());
        const hasConfidenceScore = crColumns.includes('confidence_score');
        const hasScore = crColumns.includes('score');
        const crJoinCol = crColumns.includes('comment_id') ? 'comment_id' : (crColumns.includes('id') ? 'id' : null);
        const crActualJoinCol = crJoinCol ? crSchema.find(c => c.name.toLowerCase() === crJoinCol).name : null;
        
        const tcSchema = db.prepare("PRAGMA table_info(telegram_comments)").all() as any[];
        const tcColumns = tcSchema.map(c => c.name.toLowerCase());
        
        const tcJoinCol = tcColumns.includes('id') ? 'id' : (tcColumns.includes('comment_id') ? 'comment_id' : null);
        
        const tcActualJoinCol = tcJoinCol ? tcSchema.find(c => c.name.toLowerCase() === tcJoinCol).name : null;

        debugError = `Table:${crTableName} CRcols:${crColumns.join(',')} TCcols:${tcColumns.join(',')}`;

        if (crActualJoinCol && tcActualJoinCol) {
          const scoreSelect = hasConfidenceScore ? ", cr.confidence_score as score" : (hasScore ? ", cr.score as score" : "");
          const joinQuery = `
            SELECT c.*, cr.relation ${scoreSelect}
            FROM telegram_comments c
            LEFT JOIN "${crTableName}" cr ON CAST(c.${tcActualJoinCol} AS TEXT) = CAST(cr.${crActualJoinCol} AS TEXT)
            WHERE c.post_id = ?
            ORDER BY c.date DESC
          `;
          comments = db.prepare(joinQuery).all(postId) as any[];
          debugError = ""; 
        } else {
          debugError += " MISSING JOIN COL";
          comments = db.prepare("SELECT * FROM telegram_comments WHERE post_id = ? ORDER BY date DESC").all(postId) as any[];
        }
      } catch (e: any) {
        debugError += " ERR:" + e.message;
        try {
          comments = db.prepare("SELECT * FROM telegram_comments WHERE post_id = ? ORDER BY date DESC").all(postId) as any[];
        } catch (err) {}
      }
        
      const dateMap: Record<string, number> = {};
      comments.forEach(c => {
        if (c.date) {
          const d = new Date(Number(c.date) * 1000);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:00`;
          dateMap[key] = (dateMap[key] || 0) + 1;
        }
      });
      
      commentsByDate = Object.entries(dateMap).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date));

      try {
        const relationRes = db.prepare(`SELECT relation, COUNT(*) as c FROM "${crTableName}" WHERE post_id = ? GROUP BY relation`).all(postId) as any[];
        commentsRelation = relationRes.map(r => ({ name: r.relation, value: r.c }));
      } catch (e) {
      }

      if (fileName && db !== scraperDb) {
        db.close();
      }
      
      res.json({ success: true, post, postTopic, commentsCount: comments.length, commentsByDate, commentsRelation, comments, debugError });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/posts", (req, res) => {
    try {
      const { fileName } = req.query;
      
      let db = scraperDb;
      if (fileName && typeof fileName === "string") {
        const dbPath = path.join(os.tmpdir(), fileName);
        if (fs.existsSync(dbPath)) {
          db = new Database(dbPath, { readonly: true });
        }
      }

      let posts = [];
      try {
        posts = db.prepare("SELECT post_id, text, date FROM telegram_posts ORDER BY date DESC LIMIT 100").all();
      } catch (e) {}

      if (fileName && db !== scraperDb) {
        db.close();
      }
      res.json({ success: true, posts });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // --- SCRAPER MTPROTO ROUTES ---

  let passwordResolver: ((pwd: string) => void) | null = null;
  let codeResolver: ((code: string) => void) | null = null;
  let authStatus: 'idle' | 'waiting_code' | 'waiting_password' | 'authenticated' = 'idle';

  app.get('/api/auth/status', (req, res) => {
    if (client && client.connected && authStatus !== 'waiting_code' && authStatus !== 'waiting_password') {
      authStatus = 'authenticated';
    }
    res.json({ status: authStatus });
  });

  app.post('/api/auth/start', async (req, res) => {
    try {
      const { apiId, apiHash, phone } = req.body;
      if (!apiId || !apiHash || !phone) {
        return res.status(400).json({ error: 'Missing credentials' });
      }

      currentPhone = phone;
      const stringSession = new StringSession(sessionString);
      client = new TelegramClient(stringSession, Number(apiId), apiHash, {
        connectionRetries: 5,
      });

      authStatus = 'waiting_code';
      res.json({ success: true, message: 'Started auth' });

      await client.start({
        phoneNumber: phone,
        password: async () => {
          authStatus = 'waiting_password';
          return new Promise((resolve) => {
            passwordResolver = resolve;
          });
        },
        phoneCode: async () => {
          authStatus = 'waiting_code';
          return new Promise((resolve) => {
            codeResolver = resolve;
          });
        },
        onError: (err) => {
          console.error('MTProto Auth Error:', err);
          authStatus = 'idle';
        },
      });

      sessionString = client.session.save() as unknown as string;
      authStatus = 'authenticated';

    } catch (err: any) {
      console.error('Start auth err:', err);
      authStatus = 'idle';
    }
  });

  app.post('/api/auth/provideCode', (req, res) => {
    const { code } = req.body;
    if (codeResolver) {
      codeResolver(code);
      codeResolver = null;
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Not waiting for code' });
    }
  });

  app.post('/api/auth/providePassword', (req, res) => {
    const { password } = req.body;
    if (passwordResolver) {
      passwordResolver(password);
      passwordResolver = null;
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Not waiting for password' });
    }
  });

  app.get('/api/download-db', (req, res) => {
    const { fileName, channel, posts, comments } = req.query;
    if (fileName && typeof fileName === 'string') {
      const dbPath = path.join(os.tmpdir(), fileName);
      if (fs.existsSync(dbPath)) {
        let outName = 'database.db';
        if (channel && posts !== undefined && comments !== undefined) {
           let cleanChannel = (channel as string).replace(/^@?/, '').replace(/^(?:https?:\/\/)?(?:t\.me\/)?/, '').split('/')[0];
           outName = `${cleanChannel}_${posts}p_${comments}c.db`;
        }
        return res.download(dbPath, outName);
      }
    }
    res.download("database.db");
  });

  app.get('/api/media', async (req, res) => {
    try {
      const { channel, msgId } = req.query;
      if (!channel || !msgId || !client || !client.connected) {
        return res.status(400).send("Bad Request or not connected");
      }
      
      const messages = await client.getMessages(channel as string, {
        ids: [Number(msgId)]
      });
      
      if (messages && messages.length > 0) {
        const message = messages[0];
        if (message.media) {
           const buffer = await client.downloadMedia(message);
           if (buffer) {
               res.setHeader('Cache-Control', 'public, max-age=86400');
               // Basic content type deduction
               let contentType = 'application/octet-stream';
               if (message.media.className === 'MessageMediaPhoto') {
                   contentType = 'image/jpeg';
               } else if (message.media.className === 'MessageMediaDocument') {
                   if (message.video) {
                       contentType = 'video/mp4';
                   } else {
                       // try to find mime_type from attributes
                       if (message.media.document && 'mimeType' in message.media.document) {
                           contentType = (message.media.document as any).mimeType;
                       }
                   }
               }
               res.setHeader('Content-Type', contentType);
               return res.send(buffer);
           }
        }
      }
      res.status(404).send("Media not found");
    } catch (e: any) {
      console.error('Media download error:', e);
      res.status(500).send(e.message);
    }
  });

  app.post('/api/preview', async (req, res) => {
    try {
      const { channel, useMTProto, limitMode, countLimit, dateFrom, dateTo } = req.body;
      
      const dbFileName = `scrape_${Date.now()}_${Math.random().toString(36).substring(7)}.db`;
      const sessionDbPath = path.join(os.tmpdir(), dbFileName);
      const sessionDb = new Database(sessionDbPath);
      
      sessionDb.prepare(`
        CREATE TABLE IF NOT EXISTS telegram_posts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          channel TEXT,
          post_id INTEGER,
          text TEXT,
          date INTEGER,
          views REAL,
          media_urls TEXT
        )
      `).run();

      sessionDb.prepare(`
        CREATE TABLE IF NOT EXISTS telegram_comments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          channel TEXT,
          post_id INTEGER,
          comment_id INTEGER,
          text TEXT,
          date INTEGER
        )
      `).run();

      let postsPreview: any[] = [];
      let insertPostStmt = sessionDb.prepare('INSERT INTO telegram_posts (channel, post_id, text, date, views, media_urls) VALUES (?, ?, ?, ?, ?, ?)');
      let insertCommentStmt = sessionDb.prepare('INSERT INTO telegram_comments (channel, post_id, comment_id, text, date) VALUES (?, ?, ?, ?, ?)');
      
      if (useMTProto && client && client.connected) {
        // Scrape using GramJS
        let limit = 100;
        if (limitMode === 'count' && countLimit) {
          limit = Number(countLimit);
        }
        
        const history = await client.invoke(
          new Api.messages.GetHistory({
            peer: channel,
            limit: limit,
          })
        ) as any;
        
        if (history && history.messages) {
          let groupedMessages = new Map<string, any[]>();
          let isolatedMessages: any[] = [];
          
          for (let m of history.messages) {
            if (m.className === 'Message') {
              if (m.groupedId) {
                const gId = m.groupedId.toString();
                if (!groupedMessages.has(gId)) {
                  groupedMessages.set(gId, []);
                }
                groupedMessages.get(gId)!.push(m);
              } else {
                isolatedMessages.push([m]);
              }
            }
          }
          
          let messageGroups = [...groupedMessages.values(), ...isolatedMessages];
          let commentFetchPromises: Promise<void>[] = [];

          for (let group of messageGroups) {
            let mainMsg = group.find((m: any) => m.message) || group[0];
            
            let mediaUrls: string[] = [];
            for (let m of group) {
              const hasMedia = !!m.media;
              let isVideoMedia = false;
              if (hasMedia && m.media.className === 'MessageMediaDocument' && m.media.document && 'mimeType' in m.media.document && (m.media.document as any).mimeType.includes('video')) {
                isVideoMedia = true;
              }
              const mediaUrl = hasMedia ? `/api/media?channel=${encodeURIComponent(channel)}&msgId=${m.id}${isVideoMedia ? '&type=video' : ''}` : "";
              if (mediaUrl) mediaUrls.push(mediaUrl);
            }
            
            let text = mainMsg.message || '';
            let mediaUrlsStr = mediaUrls.join(',');
            
            // Try insert post
            try {
              const existing = sessionDb.prepare('SELECT id FROM telegram_posts WHERE channel = ? AND post_id = ?').get(channel, mainMsg.id);
              if (!existing) {
                insertPostStmt.run(channel, mainMsg.id, text, mainMsg.date, mainMsg.views || 0, mediaUrlsStr);
              }
            } catch(e) {}
            
            postsPreview.push({
              id: mainMsg.id,
              text: text,
              hasImages: mediaUrls.length > 0,
              mediaCount: mediaUrls.length,
              mediaUrls: mediaUrls
            });

            // Try fetch comments
            if (mainMsg.replies && mainMsg.replies.replies > 0) {
              commentFetchPromises.push((async () => {
                try {
                  const replies = await client!.invoke(
                    new Api.messages.GetReplies({
                      peer: channel,
                      msgId: mainMsg.id,
                      limit: 100
                    })
                  ) as any;
                  if (replies && replies.messages) {
                    for (let cm of replies.messages) {
                      if (cm.className === 'Message') {
                        try {
                          const cExisting = sessionDb.prepare('SELECT id FROM telegram_comments WHERE channel = ? AND post_id = ? AND comment_id = ?').get(channel, mainMsg.id, cm.id);
                          if (!cExisting) {
                            insertCommentStmt.run(channel, mainMsg.id, cm.id, cm.message || '', cm.date);
                          }
                        } catch(e) {}
                      }
                    }
                  }
                } catch(err) {
                  console.error("Failed fetching replies for", mainMsg.id, err);
                }
              })());
            }
          }
          
          // Execute comment fetching in chunks of 5 concurrently to speed it up
          const chunkArray = <T>(arr: T[], size: number): T[][] => Array.from({ length: Math.ceil(arr.length / size) }, (v, i) => arr.slice(i * size, i * size + size));
          for (let chunk of chunkArray(commentFetchPromises, 5)) {
             await Promise.all(chunk);
          }
        }
      } else {
        // Fallback mock preview if not connected or not using MTProto
        postsPreview = [
          { id: 1, text: 'No MTProto connection. This is a mock post.', hasImages: false, mediaCount: 0 }
        ];
      }
      
      sessionDb.close();
      res.json({ success: true, postsPreview, dbFileName });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
